# Aarav Jamwal — Student Portfolio (Section AY)

A simple responsive portfolio website made using HTML and CSS.

## Files
- `index.html` — complete website source code

## Publish free with GitHub Pages
1. Sign in at https://github.com/
2. Create a **Public** repository named `aarav-jamwal-section-ay`.
3. Upload `index.html` and commit the file.
4. Open **Settings → Pages**.
5. Under Build and deployment choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
6. Wait for deployment and open the URL shown in Pages settings.

Expected URL format (replace `YOUR-GITHUB-USERNAME` with your actual username):
https://YOUR-GITHUB-USERNAME.github.io/aarav-jamwal-section-ay/

The live URL will only work after you publish the repository using your own GitHub account.
